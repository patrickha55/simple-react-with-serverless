
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'patrickha55',
  applicationName: 'serverless-udagram-app',
  appUid: '3cLXYP6b0BK0k3Vc91',
  orgUid: '6ebcadd9-e513-41c5-bbee-7f29c4502ce3',
  deploymentUid: 'a0dd2e71-33e3-4aca-98ac-d980e45bfb66',
  serviceName: 'serverless-udagram-app',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.1',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-udagram-app-dev-GetGroups', timeout: 6 };

try {
  const userHandler = require('./src/lambda/http/getGroups.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}